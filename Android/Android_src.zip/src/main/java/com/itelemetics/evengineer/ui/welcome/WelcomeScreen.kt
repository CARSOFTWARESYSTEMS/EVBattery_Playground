package com.itelemetics.evengineer.ui.welcome

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.itelemetics.evengineer.config.AppConfig
import com.itelemetics.evengineer.data.datastore.UserPreferences
import kotlinx.coroutines.launch
import com.itelemetics.evengineer.R
import androidx.compose.ui.platform.LocalContext

@Composable
fun WelcomeScreen(navController: NavController, userPreferences: UserPreferences = UserPreferences(LocalContext.current)) {
    val coroutineScope = rememberCoroutineScope()
    var acceptedTerms by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(AppConfig.BACKGROUND_COLOR)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.padding(24.dp)
        ) {
            Text(
                text = AppConfig.WELCOME_TITLE,
                style = MaterialTheme.typography.headlineLarge,
                color = Color(AppConfig.PRIMARY_COLOR)
            )

            Image(
                painter = painterResource(id = R.drawable.ev_engineer),
                contentDescription = "EV Engineer Logo",
                modifier = Modifier
                    .size(180.dp)
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .toggleable(
                        value = acceptedTerms,
                        onValueChange = { acceptedTerms = it }
                    )
            ) {
                Checkbox(
                    checked = acceptedTerms,
                    onCheckedChange = null
                )
                Spacer(modifier = Modifier.width(8.dp))
                ClickableText(
                    text = AnnotatedString("I accept the Terms and Conditions"),
                    onClick = { /* TODO: Open terms URL */ },
                    style = LocalTextStyle.current.copy(
                        color = Color.Blue,
                        textDecoration = TextDecoration.Underline
                    )
                )
            }

            Button(
                onClick = {
                    if (acceptedTerms) {
                        coroutineScope.launch {
                            userPreferences.updateWelcomeSeen(true)
                        }
                        navController.navigate("quickTour") {
                            popUpTo("welcome") { inclusive = true }
                        }
                    }
                },
                enabled = acceptedTerms,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Get Started")
            }
        }
    }
}
