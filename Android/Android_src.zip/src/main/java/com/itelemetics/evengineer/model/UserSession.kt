package com.itelemetics.evengineer.model

data class UserSession(
    val hasSeenWelcome: Boolean = false,
    val hasCompletedTour: Boolean = false,
    val hasGrantedPermissions: Boolean = false,
    val isUserActivated: Boolean = false,
    val themeMode: String = "system" // "light", "dark", or "system"
)
