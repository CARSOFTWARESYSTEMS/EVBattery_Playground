package com.itelemetics.evengineer.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.itelemetics.evengineer.config.AppConfig

@Composable
fun HomeScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Welcome to ${AppConfig.PRODUCT_NAME}",
            style = MaterialTheme.typography.headlineMedium
        )

        Button(
            onClick = {
                // TODO: Add navigation to EV Battery screen
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("EV Battery")
        }

        Button(
            onClick = {
                // TODO: Add navigation to Travel Management screen
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Travel Management")
        }
    }
}
