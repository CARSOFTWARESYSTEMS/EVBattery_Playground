package com.itelemetics.evengineer.ui.permissions

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.itelemetics.evengineer.data.datastore.UserPreferences
import kotlinx.coroutines.launch

@Composable
fun PermissionScreen(navController: NavController, userPreferences: UserPreferences = UserPreferences(LocalContext.current)) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var allGranted by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
        onResult = { permissions ->
            allGranted = permissions.all { it.value }
            if (allGranted) {
                coroutineScope.launch {
                    userPreferences.updatePermissionsGranted(true)
                }
                navController.navigate("activation") {
                    popUpTo("permissions") { inclusive = true }
                }
            }
        }
    )

    LaunchedEffect(Unit) {
        allGranted = checkAllPermissions(context)
        if (allGranted) {
            navController.navigate("activation") {
                popUpTo("permissions") { inclusive = true }
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "We need the following permissions to proceed:",
                style = MaterialTheme.typography.headlineSmall
            )

            PermissionItem("Camera", Manifest.permission.CAMERA, context)
            PermissionItem("Location", Manifest.permission.ACCESS_FINE_LOCATION, context)
            PermissionItem("Bluetooth", Manifest.permission.BLUETOOTH_CONNECT, context)
            PermissionItem("Notifications", Manifest.permission.POST_NOTIFICATIONS, context)

            Button(
                onClick = {
                    permissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.CAMERA,
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.BLUETOOTH_CONNECT,
                            Manifest.permission.POST_NOTIFICATIONS
                        )
                    )
                },
                enabled = !allGranted,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Grant Permissions")
            }
        }
    }
}

@Composable
fun PermissionItem(name: String, permission: String, context: android.content.Context) {
    val granted = ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    Text(
        text = "$name permission is ${if (granted) "granted" else "not granted"}",
        style = MaterialTheme.typography.bodyLarge
    )
}

fun checkAllPermissions(context: android.content.Context): Boolean {
    val permissions = listOf(
        Manifest.permission.CAMERA,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.POST_NOTIFICATIONS
    )
    return permissions.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
}
