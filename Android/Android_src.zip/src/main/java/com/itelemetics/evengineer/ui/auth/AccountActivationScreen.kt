package com.itelemetics.evengineer.ui.auth

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.itelemetics.evengineer.data.datastore.UserPreferences
import kotlinx.coroutines.launch
import androidx.compose.ui.platform.LocalContext


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountActivationScreen(navController: NavController, userPreferences: UserPreferences = UserPreferences(LocalContext.current)) {
    val coroutineScope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    var phoneNumber by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var isOtpSent by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .padding(24.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = if (!isOtpSent) "Enter Phone Number" else "Enter OTP",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            OutlinedTextField(
                value = if (!isOtpSent) phoneNumber else otp,
                onValueChange = {
                    if (!isOtpSent) phoneNumber = it else otp = it
                },
                label = {
                    Text(if (!isOtpSent) "Phone Number" else "OTP")
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            errorMessage?.let {
                Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 8.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    focusManager.clearFocus()
                    if (!isOtpSent) {
                        if (phoneNumber.length < 10) {
                            errorMessage = "Please enter a valid phone number"
                        } else {
                            errorMessage = null
                            isOtpSent = true
                            // In a real app, trigger OTP here
                        }
                    } else {
                        if (otp == "12345") {
                            coroutineScope.launch {
                                userPreferences.updateUserActivated(true)
                            }
                            navController.navigate("home") {
                                popUpTo("activation") { inclusive = true }
                            }
                        } else {
                            errorMessage = "Invalid OTP. Try 12345"
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (!isOtpSent) "Send OTP" else "Verify OTP")
            }
        }
    }
}
