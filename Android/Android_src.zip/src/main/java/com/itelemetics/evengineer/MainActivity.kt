package com.itelemetics.evengineer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import com.itelemetics.evengineer.viewmodel.AppViewModel
import com.itelemetics.evengineer.NavGraph
import com.itelemetics.evengineer.ui.theme.EVEngineerTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EVApp()
        }
    }
}

@Composable
fun EVApp() {
    val navController = rememberNavController()
    val viewModel: AppViewModel = viewModel()
    val session = viewModel.session.value

    val startDestination = when {
        session == null -> "welcome"
        !session.hasSeenWelcome -> "welcome"
        !session.hasCompletedTour -> "quickTour"
        !session.hasGrantedPermissions -> "permissions"
        !session.isUserActivated -> "activation"
        else -> "home"
    }

    EVEngineerTheme(themeMode = viewModel.themeMode.value ?: "system") {
        NavGraph(navController = navController, startDestination = startDestination)
    }
}
