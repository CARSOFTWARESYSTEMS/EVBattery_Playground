package com.itelemetics.evengineer.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.itelemetics.evengineer.model.UserSession
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "user_prefs")

class UserPreferences(private val context: Context) {

    companion object {
        val HAS_SEEN_WELCOME = booleanPreferencesKey("has_seen_welcome")
        val HAS_COMPLETED_TOUR = booleanPreferencesKey("has_completed_tour")
        val HAS_GRANTED_PERMISSIONS = booleanPreferencesKey("has_granted_permissions")
        val IS_USER_ACTIVATED = booleanPreferencesKey("is_user_activated")
        val THEME_MODE = stringPreferencesKey("theme_mode") // "light", "dark", "system"
    }

    val sessionFlow: Flow<UserSession> = context.dataStore.data
        .map { prefs ->
            UserSession(
                hasSeenWelcome = prefs[HAS_SEEN_WELCOME] ?: false,
                hasCompletedTour = prefs[HAS_COMPLETED_TOUR] ?: false,
                hasGrantedPermissions = prefs[HAS_GRANTED_PERMISSIONS] ?: false,
                isUserActivated = prefs[IS_USER_ACTIVATED] ?: false,
                themeMode = prefs[THEME_MODE] ?: "system"
            )
        }

    suspend fun updateWelcomeSeen(value: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[HAS_SEEN_WELCOME] = value
        }
    }

    suspend fun updateTourCompleted(value: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[HAS_COMPLETED_TOUR] = value
        }
    }

    suspend fun updatePermissionsGranted(value: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[HAS_GRANTED_PERMISSIONS] = value
        }
    }

    suspend fun updateUserActivated(value: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[IS_USER_ACTIVATED] = value
        }
    }

    suspend fun updateThemeMode(value: String) {
        context.dataStore.edit { prefs ->
            prefs[THEME_MODE] = value
        }
    }
}
