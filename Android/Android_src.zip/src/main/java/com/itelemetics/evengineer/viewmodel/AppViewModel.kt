package com.itelemetics.evengineer.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.itelemetics.evengineer.data.datastore.UserPreferences
import com.itelemetics.evengineer.model.UserSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val userPreferences = UserPreferences(application.applicationContext)

    private val _session = MutableStateFlow<UserSession?>(null)
    val session: StateFlow<UserSession?> get() = _session

    private val _themeMode = MutableStateFlow<String?>(null)
    val themeMode: StateFlow<String?> get() = _themeMode

    init {
        viewModelScope.launch {
            userPreferences.sessionFlow.collectLatest { sessionData ->
                _session.value = sessionData
                _themeMode.value = sessionData.themeMode
            }
        }
    }

    fun setThemeMode(mode: String) {
        viewModelScope.launch {
            userPreferences.updateThemeMode(mode)
        }
    }

    fun markWelcomeSeen() {
        viewModelScope.launch {
            userPreferences.updateWelcomeSeen(true)
        }
    }

    fun markTourCompleted() {
        viewModelScope.launch {
            userPreferences.updateTourCompleted(true)
        }
    }

    fun markPermissionsGranted() {
        viewModelScope.launch {
            userPreferences.updatePermissionsGranted(true)
        }
    }

    fun markUserActivated() {
        viewModelScope.launch {
            userPreferences.updateUserActivated(true)
        }
    }
}
