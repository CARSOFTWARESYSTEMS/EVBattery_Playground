package com.itelemetics.evengineer

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.itelemetics.evengineer.ui.auth.AccountActivationScreen
import com.itelemetics.evengineer.ui.home.HomeScreen
import com.itelemetics.evengineer.ui.permissions.PermissionScreen
import com.itelemetics.evengineer.ui.quicktour.QuickTourScreen
import com.itelemetics.evengineer.ui.welcome.WelcomeScreen

@Composable
fun NavGraph(navController: NavHostController, startDestination: String) {
    NavHost(navController = navController, startDestination = startDestination) {
        composable("welcome") {
            WelcomeScreen(navController)
        }
        composable("quickTour") {
            QuickTourScreen(navController)
        }
        composable("permissions") {
            PermissionScreen(navController)
        }
        composable("activation") {
            AccountActivationScreen(navController)
        }
        composable("home") {
            HomeScreen(navController)
        }
    }
}
