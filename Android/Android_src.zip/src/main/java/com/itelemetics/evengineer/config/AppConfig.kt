package com.itelemetics.evengineer.config

object AppConfig {
    const val PRODUCT_NAME = "EV Engineer"
    const val WELCOME_TITLE = "Welcome to EV Engineer"
    const val TAGLINE = "Your EV Charging, Smarter than Ever."
    const val PRIMARY_COLOR = 0xFF1B5E20
    const val BACKGROUND_COLOR = 0xFFF1F8E9
    const val LOGO_IMAGE = "evEngineer"  // Name of the drawable resource (without extension)
    const val DEFAULT_THEME_MODE = "system" // "light", "dark", or "system"
}

object AppConfigForEVBattery {
    const val PRODUCT_NAME = "EV Battery"
    const val WELCOME_TITLE = "Welcome to EV Battery"
    const val TAGLINE = "Your EV Charging, Smarter than Ever."
    const val PRIMARY_COLOR = 0xFF1B5E20
    const val BACKGROUND_COLOR = 0xFFF1F8E9
    const val LOGO_IMAGE = "evEngineer"  // Name of the drawable resource (without extension)
    const val DEFAULT_THEME_MODE = "system" // "light", "dark", or "system"
}
