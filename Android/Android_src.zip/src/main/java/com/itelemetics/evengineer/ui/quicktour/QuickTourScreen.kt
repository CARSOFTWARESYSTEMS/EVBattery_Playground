package com.itelemetics.evengineer.ui.quicktour

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext          // <<<<< Add this import
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.itelemetics.evengineer.config.AppConfig
import com.itelemetics.evengineer.data.datastore.UserPreferences
import kotlinx.coroutines.launch
import com.itelemetics.evengineer.R


@Composable
fun QuickTourScreen(navController: NavController, userPreferences: UserPreferences = UserPreferences(LocalContext.current)) {
    val coroutineScope = rememberCoroutineScope()
    var currentPage by remember { mutableStateOf(0) }

    val pages = listOf(
        TourPage("Welcome to EV Engineer", "Discover smarter EV charging.", R.drawable.e_car),
        TourPage("Track your Ride", "Monitor your EV performance in real-time.", R.drawable.e_bike),
        TourPage("Save Energy", "Optimize your charging for longer battery life.", R.drawable.e_battery)
    )

    val page = pages[currentPage]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceAround
    ) {
        Text(
            text = page.title,
            style = MaterialTheme.typography.headlineMedium
        )

        Image(
            painter = painterResource(id = page.imageRes),
            contentDescription = page.title,
            modifier = Modifier.size(180.dp)
        )

        Text(
            text = page.description,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(vertical = 16.dp)
        )

        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                enabled = currentPage > 0,
                onClick = { currentPage -= 1 }
            ) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Previous")
                Spacer(modifier = Modifier.width(4.dp))
                Text("Previous")
            }

            if (currentPage < pages.lastIndex) {
                Button(
                    onClick = { currentPage += 1 }
                ) {
                    Text("Next")
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "Next")
                }
            } else {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            userPreferences.updateTourCompleted(true)
                        }
                        navController.navigate("permissions") {
                            popUpTo("quickTour") { inclusive = true }
                        }
                    }
                ) {
                    Text("Grant Permissions")
                }
            }
        }
    }
}

data class TourPage(val title: String, val description: String, val imageRes: Int)
